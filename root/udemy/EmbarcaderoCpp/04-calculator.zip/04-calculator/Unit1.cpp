//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnAddClick(TObject *Sender)
{
	String num1str = editFirstNum->Text;
	String num2str = editSecondNum->Text;

	int num1 = num1str.ToInt();
	int num2 = num2str.ToInt();
	int sum = num1 + num2;

    labelResult->Caption = IntToStr(sum);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnClearClick(TObject *Sender)
{
	editFirstNum->Text = "";
	editSecondNum->Text = "";
    labelResult->Caption = "";
}
//---------------------------------------------------------------------------
