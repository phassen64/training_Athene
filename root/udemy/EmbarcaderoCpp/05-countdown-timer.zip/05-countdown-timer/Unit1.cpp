//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
int selectedSecs = 0;
int counter = 0;

void __fastcall TForm1::btnStartClick(TObject *Sender)
{
  String selectedStr = "0";
  int selectedIndex = listboxSelect->ItemIndex;
  selectedSecs = selectedIndex * 5;
  labelOutput->Caption = IntToStr(selectedSecs);
  counter = selectedSecs;
  timerCountdown->Enabled = true;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::timerCountdownTimer(TObject *Sender)
{
  counter--;
  if(counter<=0){
	timerCountdown->Enabled = false;
	Beep(300,1000);
  }
  labelOutput->Caption = IntToStr(counter);
}
//---------------------------------------------------------------------------
