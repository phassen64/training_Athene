object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'Forms Labels Buttons'
  ClientHeight = 231
  ClientWidth = 505
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object lblOutput: TLabel
    Left = 184
    Top = 56
    Width = 137
    Height = 41
    Caption = 'My Label'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object btnClickMe: TButton
    Left = 200
    Top = 152
    Width = 75
    Height = 25
    Caption = 'Click Me'
    TabOrder = 0
    OnClick = btnClickMeClick
  end
end
